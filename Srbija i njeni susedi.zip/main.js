const images = document.querySelectorAll('img');
const podaci = [
{
title: 'Мађарска',
url: 'pages/hu.html',
audio: new Audio('sounds/hu.ogg')
},
{
title: 'Румунија',
url: 'pages/ru.html',
audio: new Audio('sounds/ru.ogg')
},
{
title: 'Хрватска',
url: 'pages/cro.html',
audio: new Audio('sounds/cro.ogg')
},
{
title: 'Босна и Херцеговина',
url: 'pages/bih.html',
audio: new Audio('sounds/bh.ogg')
},
{
title: 'Србија',
url: 'pages/rs.html',
audio: new Audio('sounds/srb.mp3')
},
{
title: 'Црна Гора',
url: 'pages/cg.html',
audio: new Audio('sounds/cg.mp3')
},
{
title: 'Албанија',
url: 'pages/al.html',
audio: new Audio('sounds/al.ogg')
},
{
title: 'Македонија',
url: 'pages/mkd.html',
audio: new Audio('sounds/mkd.ogg')

},
{
title: 'Бугарска',
url: 'pages/bug.html',
audio: new Audio('sounds/bg.mp3')
}
]
for(let i = 0; i < images.length; i++){
images[i].addEventListener('mouseover', () => {
podaci[i].audio.play();
})
images[i].addEventListener('mouseout', () => {
podaci[i].audio.pause();
podaci[i].audio.currentTime = 0;
})
images[i].addEventListener('click', () => {
open(podaci[i].url, podaci[i].title, 'width = 300, height = 200');
})
}